import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

// Arquivo para funções utilitárias

// Função para garantir que o scroll para uma seção específica funcione corretamente
export function scrollToSection(sectionId: string, delay = 100) {
  setTimeout(() => {
    try {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: "smooth" })
      }
    } catch (error) {
      console.error(`Error scrolling to section ${sectionId}:`, error)
    }
  }, delay)
}

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
